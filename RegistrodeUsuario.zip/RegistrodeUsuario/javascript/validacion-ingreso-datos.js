const nombre= document.getElementById("Nombres"); const cedula= document.getElementById("Cedula"); const numero= document.getElementById("Numero"); const email= document.getElementById("Correo"); const contra= document.getElementById("Contraseña"); const dia= document.getElementById("Dias");
const form= document.getElementById("form-codigo");
const listinputs= document.querySelectorAll(".input-group")
form.addEventListener("submit", (e) =>{ e.preventDefault();
    let condicion=validar(); if(condicion){
    enviar();
    }
     
    });
     
    
    function validar(){ let condicion=true;
    listinputs.forEach(element => { element.lastElementChild.innerHTML="";
     
    });
    
    if(nombre.value.length < 7){
    let entrada = document.querySelector(".Nombres"); entrada.lastElementChild.innerHTML="Nombre no Valido"; condicion=false;
    }
    if(cedula.value.length < 10){
    let entrada = document.querySelector(".Cedula"); entrada.lastElementChild.innerHTML="Minimo 10 digitos"; condicion=false;
    }
    if(numero.value.length < 10 || isNaN(numero.value)){ let entrada = document.querySelector(".Numero");
    entrada.lastElementChild.innerHTML="EL numero telefonico debe contener 10 digitos";
    condicion=false;
    }
    if(email.value.length < 7){
    let entrada = document.querySelector(".Correo"); entrada.lastElementChild.innerHTML="Correo no valdido"; condicion=false;
    }
    if(contra.value.length < 7){
    let entrada = document.querySelector(".Contraseña"); entrada.lastElementChild.innerHTML="Contraseña no valida"; condicion=false;
    }
    if(dia.value.length < 1 || isNaN(dia.value)){
    let entrada = document.querySelector(".Dias"); entrada.lastElementChild.innerHTML="Numero de dias no valido"; condicion=false;
    }
    return condicion;
    }
    
    function enviar(){
        form.reset(); form.lastElementChild.innerHTML="Reservacion en Proceso";
    }
        